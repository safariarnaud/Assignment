File myFile = new File("people.txt");
try{
	
	FileInputStream fls = new FileInputStream(myFile);
	
}catch(FileNotFoundException){
	
	System.out.println("The file doesn't exists");
}

FileInputStream input = new FileInputStream("c:\\data\\people.txt");

int data = input.read();

while(data!=-1){
	
	System.out.println(data);
	data = input.read();
	input.close();
}

File inFile = new File("people.txt");
FileInputStream inStream = new FileInputStream( inFile);

int fileSize = (int)inFile.length();
byte[]byteArray = new byte[fileSize ];
inStream.read(byteArray);

for(int i = 0; i<fileSize; i++){
	
	System.out.println(byteArray);
}

inStream.close();