<html>
<head>
<title> COMPUTER SCIENTIST </title>
<body bgcolor="tan">
<link rel="stylesheet" href="style.css" />
</head>
<body>

<div class="main">

<form action="" method="POST">
<h1> COMPUTER SCIENTIST</h1>


Enter first entry ID <input type="text" name="id" /><br></br>
Enter first name <input type="text" name="first" /><br></br>
Enter Last name <input type="text" name="last" /><br></br>
Enter birth year <input type="number" name="birth" /><br></br>
Enter Death year <input type="number" name="death" /><br></br>
Enter University name <input type="text" name="univ" /><br></br>

<p>Option: <select name="choice">
<option value="e">academic affiliation</option>
<option value="c">contribution</option>

</select></p>

click here to enter <input type="submit" name="submit" value="Submit" />
</form>
</body>
</html>