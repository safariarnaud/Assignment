import java.io.*;

public class OutputStreamExample
{
	
	public static void main(String args[])throws IOException{
		
		
		File outFile = new File("savedFile.data");
		
		FileOutputStream outStream = new FileOutputStream(outFile);
		
		byte[]byteArray = {"first name", "last name"};
		
		outStream.write(byteArray );
		
		outStream.close();
	}
}